/*Write a java program that uses some methods to perform the following tasks:
• Write a method named createIntFile() that stores 300 integer numbers in the range (500-1000)
into a text file named “intNumbers.txt”.
• Write a method fillLists() that receives the “intNumbers.txt” as an argument and fills three
ArrayLists.
1. An arrayList primeList to store all prime numbers in the file without repetition (no
duplication).
2. An arrayList evenList to store all even numbers in the file without repetition (no
duplication).
3. An arrayList oddList to store all odd numbers in the file without repetition (no
duplication).
4. Hint: Create a boolean checkprime() method to check whether the prime number exists
in the arrayList primeList.
5. Create a boolean checkEven() method to check whether the even number exists in the
arrayList evenList.
6. Create a boolean checkOdd() method to check whether the odd number exists in the
arrayList oddList.
• Write a method printList() that receives a int List and prints all the numbers in ascending
(increasing) order. In the main method, call this method three times to print all list primeList,
evenList, and oddList
*
* Gerishom Muholeza
* Computer Science Two
* Project 2
* 
*/

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class Part1 {

	public static ArrayList<Integer> primeList = new ArrayList<Integer>();

	public static ArrayList<Integer> evenList = new ArrayList<Integer>();

	public static ArrayList<Integer> oddList = new ArrayList<Integer>();

	public static void main(String[] args) {
		createIntFile();
		ArrayList<Integer> fullInput = fillLists();

		fullInput = cleanUpList(fullInput);

		Collections.sort(fullInput);

		for (int i = 0; i < fullInput.size(); i++) {
			int number = fullInput.get(i);
			if (checkEven(number)) {
				evenList.add(number);
			}
			if (checkPrime(fullInput.get(i))) {
				primeList.add(number);
			}
		}
		for (int i = 0; i < fullInput.size(); i++) {
			String outputString = ">" + fullInput.get(i);
			outputString += "|" + (checkEven(fullInput.get(i)) ? "even" : "odd");
			outputString += checkPrime(fullInput.get(i)) ? "| PRIME" : "| NOT PRIME";

			System.out.println(outputString);
		}

		System.out.println("---------------------");
		System.out.println("Full onput amout: " + fullInput.size());
		System.out.println("Even count: " + evenList.size());
		System.out.println("Odd count: " + (fullInput.size() - oddList.size()));
		System.out.println("Prime count: " + primeList.size());
	}

	public static ArrayList<Integer> cleanUpList(ArrayList<Integer> input) {
		ArrayList<Integer> output = new ArrayList<Integer>();

		for (int i = 0; i < input.size(); i++) {
			boolean canContinue = true;
			if (canContinue) {
				for (int t = 0; t < input.size(); t++) {

				}
				output.add(input.get(i));
			}
		}
		return output; // a Return
	}

	public static ArrayList<Integer> fillLists() { // This will read the file, intNumbers.txt
		ArrayList<Integer> output = new ArrayList<Integer>();
		// Now read the file
		try {
			BufferedReader bufferedReader = new BufferedReader(new FileReader("intNumbers.txt"));
			String input = "";

			while ((input = bufferedReader.readLine()) != null) { // While our input is not empty
				output.add(Integer.parseInt(input));
			}

			bufferedReader.close(); // ALWAYS CLOSE bufferreaders!
		} catch (Exception e) {
			System.out.println("A reading error had occured"); // Provide an error
		}
		return output;
	}

	public static void createIntFile() { // This will write our file
		try {
			FileWriter writer = new FileWriter("intNumbers.txt");
			Random random = new Random();
			for (int i = 0; i < 150; i++) { // 300 times
				writer.write(Integer.toString(random.nextInt(501) + 500) + "\n"); // generate values from 500-1000
			}

			writer.close(); // CLOSE WRITERES
		} catch (IOException e) {
			System.out.println("A writing error had occured");
		}
	}

	public static boolean checkPrime(int input) { // Check if prime, this formula was provided from an online source.
		if (input == 1 || input < 1) {
			return false;
		}
		for (int i = 2; i < Math.sqrt(input); i++) {
			if (input % i == 0) {
				return false;
			}
		}
		return true;
	}

	public static boolean checkEven(int input) { // This is as simple as it gets.
		return input % 2 == 0;
	} // We will not use a checkOdd method, because we will get the full count - even
		// count = odd count

}
