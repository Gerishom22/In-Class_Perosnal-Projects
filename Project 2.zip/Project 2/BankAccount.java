/*
 * Gerishom Muholeza
 * Part 2
 * 02/07/2024
 * 
 */

public class BankAccount {

	// Data members
	private String customerName;
	private String email;
	private String accountID;
	private double balance;

	public BankAccount(String customerName, String email, String accountID, double balance) {
		// Constructor with arguments
		this.customerName = customerName;
		this.email = email;
		this.accountID = accountID;
		this.balance = balance;
	}

	// Setters and getters
	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAccountID() {
		return accountID;
	}

	public void setAccountID(String accountID) {
		this.accountID = accountID;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	// toString method
	@Override
	public String toString() {
		return "BankAccount{" + "customerName='" + customerName + '\'' + ", email='" + email + '\'' + ", accountID='"
				+ accountID + '\'' + ", balance=" + balance + '}';
	}

	// deposit method
	public void deposit(double amount) {
		balance += amount;
		System.out.println("Deposit of $" + amount + " successful. New balance: $" + balance);
	}

	// withdraw method
	public void withdraw(double amount) {
		if (amount > balance) {
			System.out.println("Insufficient funds. Withdrawal unsuccessful.");
		} else {
			balance -= amount;
			System.out.println("Withdrawal of $" + amount + " successful. New balance: $" + balance);
		}
	}

	// taxRate method
	public double taxRate() {
		if (balance < 15000) {
			return 0.03 * balance;
		} else if (balance <= 30000) {
			return 0.05 * balance;
		} else {
			return 0.08 * balance;
		}
	}

	public static void main(String[] args) {
		// Testing the BankAccount class
		BankAccount account = new BankAccount("Gerishom Muholeza", "Muholeza@example.com", "123456", 20000.0);

		System.out.println("Initial account details:");
		System.out.println(account);

		account.deposit(5000);
		account.withdraw(3000);

		System.out.println("Tax rate: $" + account.taxRate());

		System.out.println("Updated account details:");
		System.out.println(account);
	}
}