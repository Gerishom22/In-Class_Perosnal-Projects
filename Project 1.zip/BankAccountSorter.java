import java.util.Scanner;

public class BankAccountSorter {
    public static void main(String[] args) {
        // Scanner for user input
        Scanner scanner = new Scanner(System.in);

        // Step 1: User Input - Number of bank accounts
        System.out.print("Enter the number of bank accounts: ");
        int numberOfAccounts = scanner.nextInt();

        // Arrays to store bank account details
        String[] customerNames = new String[numberOfAccounts];
        int[] accountIDs = new int[numberOfAccounts];
        double[] checkingBalances = new double[numberOfAccounts];
        double[] savingBalances = new double[numberOfAccounts];

        // Data Entry - For each account
        for (int i = 0; i < numberOfAccounts; i++) {
            System.out.println("Enter details for Account " + (i + 1) + ":");
            System.out.print("Customer Name: ");
            customerNames[i] = scanner.next();
            System.out.print("Account ID: ");
            accountIDs[i] = scanner.nextInt();
            System.out.print("Checking Balance: $");
            checkingBalances[i] = scanner.nextDouble();
            System.out.print("Saving Balance: $");
            savingBalances[i] = scanner.nextDouble();
        }

        //Sorting based on saving balance in descending order
        sortAccountsBySavingBalance(customerNames, accountIDs, checkingBalances, savingBalances);

        //Output Format - Print the sorted records
        System.out.println("Sorted records based on Saving Balance in descending order:");
        for (int i = 0; i < numberOfAccounts; i++) {
            System.out.println("-------------------------------------");
            System.out.println("Customer Name : " + customerNames[i]);
            System.out.println("Account ID : " + accountIDs[i]);
            System.out.println("Checking Balance : $" + checkingBalances[i]);
            System.out.println("Saving Balance : $" + savingBalances[i]);
        }

        // Close the scanner
        scanner.close();
    }

    // Helper method to sort accounts based on saving balance in descending order
    private static void sortAccountsBySavingBalance(String[] names, int[] ids, double[] checkingBalances, double[] savingBalances) {
        int length = savingBalances.length;

        // Custom sorting based on saving balance
        for (int i = 0; i < length - 1; i++) {
            for (int j = 0; j < length - i - 1; j++) {
                if (savingBalances[j] < savingBalances[j + 1]) {
                    // Swap elements
                    swap(names, j, j + 1);
                    swap(ids, j, j + 1);
                    swap(checkingBalances, j, j + 1);
                    swap(savingBalances, j, j + 1);
                }
            }
        }
    }

    // Helper method to swap elements in arrays
    private static void swap(String[] array, int i, int j) {
        String temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }

    private static void swap(int[] array, int i, int j) {
        int temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }

    private static void swap(double[] array, int i, int j) {
        double temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }
}


