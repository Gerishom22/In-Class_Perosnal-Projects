import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
	      Scanner scnr = new Scanner(System.in);
	      System.out.println("please provide a sequnce count");
	      int sequence = scnr.nextInt();
	      
	      int a = 0;
	      int b = 1;
	      int c = 0;
	      
	      System.out.println("0, 1");
	      
	      for(byte i = 0; i < sequence - 2; i++) {
	    	  c = a + b; 
	    	  a = b;
	    	  b = c;
	    	  System.out.println(c);
	    	  
	      }
	      }

	}


