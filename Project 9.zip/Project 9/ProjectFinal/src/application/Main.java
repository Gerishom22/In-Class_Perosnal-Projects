package application;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class Main extends Application {
	
	ComboBox myComboBox = new ComboBox();
	private void fillComboBoxFromFile() throws FileNotFoundException
	{
	Scanner fileIn = new Scanner(new File("myfile.txt"));
	while (fileIn.hasNext()) {
	String currentNaton = fileIn.nextLine();
	myComboBox.getItems().add(currentNaton);
	}
	fileIn.close();
	}
	
	@Override
	public void start(Stage primaryStage) {
		try {

			VBox vBox = new VBox();
			vBox.setPadding(new Insets(10, 10, 10, 10));
			vBox.setSpacing(10);

			HBox h1 = new HBox();
			h1.setPadding(new Insets(10, 10, 0, 10));
			h1.setSpacing(10);

			HBox h2 = new HBox();
			h2.setPadding(new Insets(0, 10, 0, 10));
			h2.setSpacing(10);

			Label UN = new Label("Student Full Name: ");
			Label PS = new Label("Students Email Ad: ");
			
			TextField TUN = new TextField();
			TUN.setPromptText("Student Full Name");
			TextField TP = new TextField();
			TP.setPromptText("Student Email Address");

			h1.getChildren().addAll(UN, TUN);
			h2.getChildren().addAll(PS, TP);

			HBox hBox3 = new HBox();
			hBox3.setPadding(new Insets(0, 10, 0, 10));
			hBox3.setSpacing(10);

			Label nLa = new Label("Student Nationality:");
			ComboBox<String> nCB = new ComboBox<>();

			try {
				File file = new File("nations-1.txt");
				Scanner sc = new Scanner(file);
				while (sc.hasNextLine()) {
					String nationality = sc.nextLine();
					nCB.getItems().add(nationality);
				}
				sc.close();
			} catch (FileNotFoundException e) {
				System.err.println("File not found: " + e.getMessage());
			}

			if (nCB.getItems().isEmpty()) {
				nCB.getItems().addAll("United States", "United Kingdom", "Canada", "Australia");
			}

			hBox3.getChildren().addAll(nLa, nCB);

			// Fourth HBox for Student Level
			HBox hBox4 = new HBox();
			hBox4.setPadding(new Insets(0, 10, 0, 10));
			hBox4.setSpacing(10);

			Label levelLabel = new Label("Student Level:");
			ToggleGroup lTG = new ToggleGroup();
			RadioButton uRB = new RadioButton("Undergraduate");
			RadioButton gRB = new RadioButton("Graduate");
			
			uRB.setSelected(true); // Set default selection
			uRB.setToggleGroup(lTG);
			gRB.setToggleGroup(lTG);

			hBox4.getChildren().addAll(levelLabel, uRB, gRB);

			// Fifth HBox for Transferred Student
			HBox hBox5 = new HBox();
			hBox5.setPadding(new Insets(0, 10, 10, 10));
			hBox5.setSpacing(10);

			CheckBox tCB = new CheckBox("Transferred Student");

			hBox5.getChildren().addAll(tCB);

			HBox hB = new HBox();
			Button bL = new Button("save");
			bL.setPrefSize(80, 40);
			Button bC = new Button("reset");
			bC.setPrefSize(80, 40);
			
			hB.getChildren().addAll(bL, bC);
			hB.setPadding(new Insets(0, 12, 15, 12));
			hB.setSpacing(10);
			hB.setAlignment(Pos.TOP_CENTER);
			
			bL.setOnAction(event -> {
				String fullName = TUN.getText();
				String email = TP.getText();
				String nationality = nCB.getValue();
				String level = uRB.isSelected() ? "Undergraduate" : "Graduate";
				boolean transferred = tCB.isSelected();

				// Format the data
				String data = String.format("Full Name: %s\nEmail: %s\nNationality: %s\nLevel: %s\nTransferred: %s\n\n",
						fullName, email, nationality, level, transferred ? "Yes" : "No");

				try (FileWriter writer = new FileWriter("records.txt", true)) {
					writer.write(data);
				} catch (IOException e) {
					e.printStackTrace();
				}

				// Clear the fields after saving
				TUN.clear();
				TP.clear();
				nCB.getSelectionModel().clearSelection();
				uRB.setSelected(true);
				tCB.setSelected(false);
			});
			
			bC.setOnAction(event -> {
			    TUN.clear();
			    TP.clear();
			    nCB.getSelectionModel().clearSelection();
			    uRB.setSelected(true);
			    tCB.setSelected(false);
			});
			
			vBox.getChildren().addAll(h1, h2, hBox3, hBox4, hBox5, hB);
			
			BorderPane root = new BorderPane();
			root.setCenter(vBox);

			Scene scene = new Scene(root, 400, 400);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		launch(args);
	}
}
