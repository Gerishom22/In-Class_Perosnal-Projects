import java.util.Random;

class Fleet implements FleetAPI {
	final int FLEETSIZE = 7; // number of battleships
	Ship[] ships = new Ship[FLEETSIZE]; // battleships of the fleet

	public Ship[] getShips() {
		return ships;
	}

	public void setShips(Ship[] ships) {
		this.ships = ships;
	}

	public int getFLEETSIZE() {
		return FLEETSIZE;
	}

	public Fleet() {
		for (int i = 0; i < FLEETSIZE; i++) {
			ships[i] = new Ship();

		}

	}

	@Override
	public void deployFleet() {

		for (int i = 0; i < FLEETSIZE; i++) {
			Location L = new Location();
			L.pick();
			ships[i].setLoc(L);

		}
	}

	@Override
	public boolean operational() {
		for (Ship s1 : ships) {
			if (!s1.isSunk()) {
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean isHitNSink(Location location) {
		for (Ship s1 : ships) {
			if (s1.match(location)) {
				s1.sink();
				return true;
			}
		}
		return false;
	}

	@Override
	public void printFleet() {
		for (int i = 0; i < FLEETSIZE; i++) {
			ships[i].printShip();
		}
	}

	@Override
	public int check(Location location) {
		for (int i = 0; i < FLEETSIZE; i++) {
			if (ships[i].getLoc().equals(location)) {
				return i;
			}
		}
		return -1;
	}
}
