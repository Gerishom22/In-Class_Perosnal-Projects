import static org.junit.Assert.*;
import org.junit.Test;

public class ShipTest {

    @Test
    public void testDefaultConstructor() {
        Ship ship = new Ship();
        assertFalse(ship.isSunk());
    }

    @Test
    public void testSetLocation() {
        Ship ship = new Ship();
        Location location = new Location(3, 'c');
        ship.setLocation(location);
        assertEquals(location, ship.getLoc());
    }

    @Test
    public void testMatch() {
        Ship ship = new Ship();
        Location location = new Location(3, 'c');
        ship.setLocation(location);

        assertTrue(ship.match(location));
    }

    @Test
    public void testIsSunk() {
        Ship ship = new Ship();
        assertFalse(ship.isSunk());
        ship.sink();
        assertTrue(ship.isSunk());
    }

    @Test
    public void testPrintShip() {
        Ship ship = new Ship();
        Location location = new Location(3, 'c');
        ship.setLocation(location);
        
    }

}

   

