import static org.junit.Assert.*;
import org.junit.Test;

public class LocationTest {

    @Test
    public void testDefaultConstructor() {
        Location location = new Location();
        assertEquals(1, location.getX());
        assertEquals('*', location.getY());
    }

    @Test
    public void testParameterizedConstructor() {
        Location location = new Location(3, 'c');
        assertEquals(3, location.getX());
        assertEquals('c', location.getY());
    }

    @Test
    public void testPick() {
        Location location = new Location();
        location.pick();
        assertTrue(location.getX() >= 1 && location.getX() <= 7);
        assertTrue(location.getY() >= 'a' && location.getY() <= 'g');
    }

    @Test
    public void testFire() {
    }

    @Test
    public void testPrint() {
        Location location = new Location(4, 'd');
    }
}