import java.util.Random;
import java.util.Scanner;

public class Location implements LocationAPI{

	private int x;
	private char y;
	
	public Location() {
		this.x=1;
		this.y='*';
	}
	
	public Location (int x, char y){
		this.x= x;
		this.y= y; 
	}
	
	
	public int getX() {
		return this.x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public char getY() {
		return this.y;
	}

	public void setY(char y) {
		this.y = y;
	}

	@Override
	public void pick() {
		Random rand=new Random();
		
		this.x = rand.nextInt(7)+1;
		this.y = (char)(rand.nextInt(7)+97);
	}

	@Override
	public void fire() {
		Scanner console = new Scanner(System.in);
		System.out.println("\n\nPlease enter Coordinates x [1, 7] and y [a, g]");
		
		boolean test = true;
		
		while(test ==true) {
			System.out.print("Enter y[a, g] -> ");
			char letter = console.next().charAt(0);
			
			if (letter >= 'a' && letter <= 'g') {
				this.y = letter;
				test= false;
			}
		}
		test = true;
		
		
		while(test ==true) {
			System.out.print("Enter x[1-7] -> ");
			int number = console.nextInt();
			
			if (number >= 1 && number <= 7) {
				this.x = number;
				test= false; 
			}
		}
		test = true;
	}

	@Override
	public void print() {
		System.out.print(this.y+""+this.x + " ");
	}


}
