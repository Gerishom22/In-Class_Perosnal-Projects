
public interface LocationAPI {
	
	
	void pick(); // picks a random location
	
	void fire(); // asks the user to input coordinates of the next shot
	
	void print(); // prints location in format "a1" (y and x)
	

}
