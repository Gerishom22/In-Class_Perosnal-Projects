import java.util.Scanner;

public class DriverApp {
    public static void main(String[] args) {
        System.out.println("Gerishom BattleShip game");

        Fleet f1 = new Fleet();
      
        Scanner scanner = new Scanner(System.in);
        boolean test = true;
        f1.deployFleet();
        
        while(test) {
        	System.out.println("Do you want to print ships' Positions and status? (y/n): ");
        	
        	char letter = scanner.nextLine().charAt(0);
        	
        	if(letter == 'y') {
        		f1.printFleet();
        		test = false;
        	} else if (letter == 'n'){
        		test = false;
        	}
        	
        	
        }
        // Assuming you want to take user input for firing coordinates
        while (f1.operational()) {

            Location l1 = new Location();
            l1.fire();  // Pass the scanner to the fire method to get user input
            f1.check(l1);
            boolean hit = f1.isHitNSink(l1);

            if (hit) {
                System.out.println("Hit!");
            } else {
                System.out.println("Miss!");
            }
            
            test = true;
            
            while(test) {
            	System.out.println("Do you want to print ships' Positions and status? (y/n): ");
            	
            	char letter = scanner.nextLine().charAt(0);
            	
            	if(letter == 'y') {
            		f1.printFleet();
            		test = false;
            	} else if (letter == 'n'){
            		test = false;
            	}
            	
            	
            }
        }

        scanner.close();  // Close the scanner when done
        System.out.println("Game Over!");
    }
}
