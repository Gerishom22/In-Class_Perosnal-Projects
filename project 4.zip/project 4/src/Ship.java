
public class Ship implements ShipAPI {
	
    private Location loc = new Location();;
    private boolean sunk;

    public Ship (){
		this.sunk = false; 
	}

    public Location getLoc() {
        return loc;
    }

    public void setLoc(Location loc) {
        this.loc = loc;
    }

    public void setSunk(boolean sunk) {
        this.sunk = sunk;
    }

    @Override
    public boolean match(Location location) {
       boolean isMatch= false;
       if(loc.getX()== location.getX() && loc.getY() == location.getY()) {
    	   isMatch = true;
       }
       return isMatch;
    }

    @Override
    public boolean isSunk() {
        return sunk;
    }

    @Override
    public void sink() {
        sunk = true;
    }

    @Override
    public void setLocation(Location location) {
    	location.pick();
        this.loc = location;
    }

    @Override
    public void printShip() {
        loc.print();
        if (sunk) {
            System.out.print("sunk,");
        } else {
            System.out.print("up");
        }
        System.out.print(" , ");
    }

	public boolean getLocation() {
		// TODO Auto-generated method stub
		return false;
	}
}