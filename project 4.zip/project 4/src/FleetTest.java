import static org.junit.Assert.*;
import org.junit.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

public class FleetTest {

    @Test
    public void testDeployFleet() {
        Fleet fleet = new Fleet();
        fleet.deployFleet();

        Ship[] ships = fleet.getShips();
        for (Ship ship : ships) {
            assertNotNull(ship.getLoc());
        }
    }

    @Test
    public void testOperational() {
        Fleet fleet = new Fleet();
        assertTrue(fleet.operational());

        for (Ship ship : fleet.getShips()) {
            ship.sink();
        }

        assertFalse(fleet.operational());
    }

    @Test
    public void testIsHitNSink() {
        Fleet fleet = new Fleet();
        Location location = new Location(3, 'c');
        fleet.getShips()[0].setLoc(location);

        assertTrue(fleet.isHitNSink(location));
        assertTrue(fleet.getShips()[0].isSunk());
    }

    @Test
    public void testPrintFleet() {
        Fleet fleet = new Fleet();

        // Redirecting output to capture printed output
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        fleet.printFleet();

        // Reset System.out to console
        System.setOut(System.out);
    }

    @Test
    public void testCheck() {
        Fleet fleet = new Fleet();
        Location location = new Location(3, 'c');
        fleet.getShips()[0].setLoc(location);

        assertEquals(0, fleet.check(location));
        assertEquals(-1, fleet.check(new Location(1, 'a')));
    }
}
