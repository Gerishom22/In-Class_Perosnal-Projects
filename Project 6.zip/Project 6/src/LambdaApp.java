import java.util.ArrayList;

@FunctionalInterface
interface GenFun<T, B, R>{
    R task(T t, B b);
}

public class LambdaApp {
    
    public static void main(String[] args) {
        try {
            GenFun<ArrayList<String>, ArrayList<String>, ArrayList<String>> ref = (list1, list2) -> {
                ArrayList<String> result = new ArrayList<>();
                for(int i = 0; i < list1.size(); i++) {
                    result.add(list1.get(i));
                }
                for(int i = 0; i < list2.size(); i++) {
                    result.add(list2.get(i));
                }
                return result;
            };
            
            ArrayList<String> list1 = new ArrayList<>();
            list1.add("Ben");
            list1.add("Mark");
            list1.add("Emily");
            
            ArrayList<String> list2 = new ArrayList<>();
            list2.add("Michael");
            list2.add("Jason");
            list2.add("Jane");
            list2.add("Hana");
            
            ArrayList<String> combine = ref.task(list1, list2);
            System.out.println(combine);
            
            GenFun<Integer, Integer, Boolean> checkPrime = (num1, num2) -> {
                boolean prime1 = true;
                boolean prime2 = true;
                boolean bothPrime;
                
                for (int i = 2; i <= Math.sqrt(num1); i++) {
                    if (num1 % i == 0) {
                        prime1 = false;
                        break;
                    } else if (num1 == 1) {
                        prime1 = true;
                    }
                }
                
                for (int i = 2; i <= Math.sqrt(num2); i++) {
                    if (num2 % i == 0) {
                        prime2 = false;
                        break;
                    } else if (num2 == 1) {
                        prime2 = true;
                    }
                }
                
                bothPrime = prime1 && prime2;
                return bothPrime;
            };
            
            System.out.println(checkPrime.task(5, 7));
            System.out.println(checkPrime.task(12, 13));
            System.out.println(checkPrime.task(20, 2));
        } catch (Exception e) {
            System.out.println("An error occurred: " + e.getMessage());
            e.printStackTrace();
        }
    }
}