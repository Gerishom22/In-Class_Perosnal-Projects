
public class product {
	
	private String description;
	private double price;
	
	public product(String description, double price) {
		// Constructor with arguments
		this.description= description;
		this.price = price;
	}
	
	public String getdescription() {
		return description;
	}
	
	public double price() {
		return price;
	}


}