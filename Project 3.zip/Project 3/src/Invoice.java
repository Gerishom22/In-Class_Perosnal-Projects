import java.util.ArrayList;

class Invoice {
    private String customerName;
    private Address billingAddress;
    private ArrayList<lineItem> lineItems;

    public Invoice(String customerName, Address billingAddress) {
        this.customerName = customerName;
        this.billingAddress = billingAddress;
        this.lineItems = new ArrayList<>();
    }

    public void addLineItem(lineItem lineItem) {
        lineItems.add(lineItem);
    }

    public double getTotalAmount() {
        double totalAmount = 0;
        for (lineItem lineItem : lineItems) {
            totalAmount += lineItem.getTotal();
        }
        return totalAmount;
    }

    public void printInvoice() {
        System.out.println("Invoice\n" + customerName);
        System.out.println(billingAddress);
        System.out.printf("%-15s $%-10s %-4s $%-10s\n", "Description", "Price", "Qty", "Total");
        for (lineItem lineItem : lineItems) {
            System.out.println(lineItem);
        }
        System.out.printf("\nAmount Due: $%-10.2f", getTotalAmount());
    }
}
