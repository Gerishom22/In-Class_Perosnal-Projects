
public class Driver {
    public static void main(String[] args) {
        // Create products
        product Banana = new product("Banana", 2.95);
        
        product Apple = new product("Apple", 1.95);
        
        product Orange = new product("Orange", 1.99);

        // Create line items
        lineItem item1 = new lineItem(Banana, 7);
        lineItem item2 = new lineItem(Apple, 6);
        lineItem item3 = new lineItem(Orange, 8);

        // Create billing address
        Address billingAddress = new Address("100 Main Street", "Anytown", "Wisconsin", "54555");

        // Create invoice and add line items
        Invoice invoice = new Invoice("Gerishom Fruit Shop", billingAddress);
        invoice.addLineItem(item1);
        invoice.addLineItem(item2);
        invoice.addLineItem(item3);

        // Print the invoice
        invoice.printInvoice();
    }
}
