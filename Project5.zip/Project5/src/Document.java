import java.util.Objects;

public abstract  class Document {
	
	// Data member variable to store textual content
    private String text;
    
    // Constructor
    public Document(String text) {
        this.text = text;
    }

    // Getter for text
    public String getText() {
        return text;
    }

    // Setter for text
    public void setText(String text) {
        this.text = text;
        
    }
        

	@Override
	public String toString() {
		return text + "\n";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Document other = (Document) obj;
		return Objects.equals(text, other.text);
	}

	// Abstract method to check if the document contains a keyword
	public abstract boolean containsKeyword(String keyword);

	
	// Abstract method to return the length of the text
	public abstract int fileLength();
	
}
	 