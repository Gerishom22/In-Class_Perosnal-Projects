import java.util.Objects;

public class File extends Document{
	
	 private String pathname;
	    
	   public File(String text, String pathname) {
			super(text);
			this.pathname = pathname;
		}

	    // Getter for pathname
	    public String getPathname() {
	        return pathname;
	    }

	    // Setter for pathname
	    public void setPathname(String pathname) {
	        this.pathname = pathname;
	    }

	    // toString method to represent the object as a string
	    @Override
	    public String toString() {
	        return  pathname + "\n";
	    }

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (!super.equals(obj))
				return false;
			if (getClass() != obj.getClass())
				return false;
			File other = (File) obj;
			return Objects.equals(pathname, other.pathname);
		}
	    
		@Override
	    public boolean containsKeyword(String keyword) {
	        return getText().contains(keyword) || 
	        		pathname.contains(keyword);
	    }


		@Override
	    public int fileLength() {
	        return getText().length();
	    }
}
