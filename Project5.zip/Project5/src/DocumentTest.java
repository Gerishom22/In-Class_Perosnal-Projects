import static org.junit.Assert.*;
import org.junit.Test;

public class DocumentTest {

    @Test
    public void testEmailContainsKeyword() {

        Email email = new Email("Hello there", "sender@example.com", "recipient@example.com", "Sample Email");
        boolean containsKeyword = email.containsKeyword("Hello");
        assertTrue(containsKeyword);
    }

    @Test
    public void testEmailFileLength() {
    	
        Email email = new Email("Hello there", "sender@example.com", "recipient@example.com", "Sample Email");
        int length = email.fileLength();
        assertEquals(11, length);
    }

    @Test
    public void testGeneralFileContainsKeyword() {
    	
        File file = new File("This is a test", "/path/to/file.txt");
        boolean containsKeyword = file.containsKeyword("test");
        assertTrue(containsKeyword);
    }

    @Test
    public void testGeneralFileFileLength() {
     
        File file = new File("This is a test", "/path/to/file.txt");
        int length = file.fileLength();
        assertEquals(14, length);
    }
}