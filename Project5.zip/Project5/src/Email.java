import java.util.Objects;

public class Email extends Document {
  
	// Data member variable to store textual content
	private String sender;
    private String recipient;
    private String title;

    // Constructor
	public Email(String text, String sender, String recipient, String title) {
		super(text);
		this.sender = sender;
		this.recipient = recipient;
		this.title = title;
	}

	 // Getter 
	public String getSender() {
		return sender;
	}

	// Setter
	public void setSender(String sender) {
		this.sender = sender;
	}

	 // Getter 
	public String getRecipient() {
		return recipient;
	}

	// Setter
	public void setRecipient(String recipient) {
		this.recipient = recipient;
	}

	 // Getter 
	public String getTitle() {
		return title;
	}

	// Setter
	public void setTitle(String title) {
		this.title = title;
	}

	// toString method to represent the object as a string
    
	@Override
	public String toString() {
		return  sender + ",\n" + recipient + ", \n" + title + ", \n";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Email other = (Email) obj;
		return Objects.equals(recipient, other.recipient) && Objects.equals(sender, other.sender)
				&& Objects.equals(title, other.title);
	}
	
	
	
	@Override
    public boolean containsKeyword(String keyword) {
        return getText().contains(keyword) || 
        		sender.contains(keyword) || 
        		recipient.contains(keyword) || 
        		title.contains(keyword);
    }


	@Override
    public int fileLength() {
        return getText().length();
    }
}
