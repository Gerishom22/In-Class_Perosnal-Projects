import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class DocumentApp {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("\033[1mSuper Secret Information\033[0m");
        System.out.println("-------------------------------------------");
        System.out.println("Enter the file name (with .txt extension):");
        String fileName = scanner.nextLine();

        try {
            Document doc = readDocumentFromFile(fileName);
            if (doc != null) {
                System.out.println("Document content:");
                System.out.println(doc.getText());
                System.out.println("---------------------------------------------------------------------------");
                System.out.println("Enter 'search' to search for a keyword or 'length' to get the file length:");
                String action = scanner.nextLine();
                if ("search".equalsIgnoreCase(action)) {
                    System.out.println("Enter a keyword to search:");
                    String keyword = scanner.nextLine();
                    boolean containsKeyword = doc.containsKeyword(keyword);
                    System.out.println("Document contains keyword '" + keyword + "': " + containsKeyword);
                } else if ("length".equalsIgnoreCase(action)) {
                    int fileLength = doc.fileLength();
                    System.out.println("Document length: " + fileLength);
                } else {
                    System.out.println("Invalid action. Please enter 'search' or 'length'.");
                }
            } else {
                System.out.println("Failed to read the document from the file.");
            }
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        } catch (InvalidFileNameException e) {
            System.out.println("Invalid file name: " + e.getMessage());
        } finally {
            scanner.close();
        }
    }

    public static Document readDocumentFromFile(String fileName) throws IOException, InvalidFileNameException {
        if (!fileName.endsWith(".txt")) {
            throw new InvalidFileNameException("File name must have .txt extension.");
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            StringBuilder content = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                content.append(line).append("\n");
            }
            if (fileName.contains("email")) {
                return new Email(content.toString(), "sender@example.com", "recipient@example.com", "Sample Email");
            } else {
                return new File(content.toString(), "/path/to/file");
            }
        }
    }

    static class InvalidFileNameException extends Exception {
        public InvalidFileNameException(String message) {
            super(message);
        }
    }
}
